from .VerdictFormat import Formal_to_Test
from .VerdictFormat import Test_to_Formal